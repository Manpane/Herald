java -jar LogSim.jar
